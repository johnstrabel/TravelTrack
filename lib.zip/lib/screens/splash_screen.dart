import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/auth_service.dart';
import '../services/data_clear_service.dart';
import 'auth_screen.dart';
import 'username_setup_screen.dart';
import 'world_map_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
  }

  Future<void> _checkAuthStatus() async {
    await Future.delayed(const Duration(seconds: 1));

    if (!mounted) return;

    final session = Supabase.instance.client.auth.currentSession;

    if (session != null) {
      // User is logged in - check if THEY have a profile in Supabase
      final userId = session.user.id;

      print('🔍 Checking profile for user: $userId');

      try {
        final profile = await AuthService.getUserProfile(userId);

        if (!mounted) return;

        if (profile == null) {
          // No profile in Supabase for THIS user - clear old data and go to setup
          print(
            '❌ No profile found - clearing cache and going to username setup',
          );

          await DataClearService.clearAllUserData();

          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const UsernameSetupScreen()),
          );
        } else {
          // Profile exists in Supabase - go to main app
          print('✅ Profile found: ${profile.username}');
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const WorldMapScreen()),
          );
        }
      } catch (e) {
        print('⚠️ Error checking profile: $e');
        // If error, clear data and go to setup
        await DataClearService.clearAllUserData();

        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const UsernameSetupScreen()),
        );
      }
    } else {
      // Not logged in - clear everything and go to auth screen
      print('🔓 No session - clearing cache and going to auth screen');

      await DataClearService.clearAllUserData();

      if (!mounted) return;
      Navigator.of(
        context,
      ).pushReplacement(MaterialPageRoute(builder: (_) => const AuthScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF5B7C99),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.travel_explore, size: 100, color: Colors.white),
            const SizedBox(height: 24),
            const Text(
              'Travel Tracker',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 48),
            const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}
